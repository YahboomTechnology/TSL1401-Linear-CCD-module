#include "app_motor.h"

#define CCD_PID_KP       (90)
#define CCD_PID_KI       (0)
#define CCD_PID_KD       (10)

#define MID_ERR         0

static float speed_lr = 0;
static float speed_fb = 0;
static float speed_spin = 0;
static int speed_L1_setup = 0;
static int speed_L2_setup = 0;
static int speed_R1_setup = 0;
static int speed_R2_setup = 0;

// 返回当前小车轮子轴间距和的一半   Returns half of the current sum of the wheel axle distances
static float Motion_Get_APB(void)
{
    return STM32Car_APB;
}

float APP_ELE_PID_Calc(int8_t actual_value)
{
	float pid_out = 0;
	int8_t error;
	static int8_t error_last=0;
	static float Integral;//积分    integral
	
	error=actual_value-MID_ERR;
	
	Integral +=error;
		
	//位置式pid Positional pid
	pid_out=error*CCD_PID_KP
							+CCD_PID_KI*Integral
							+(error - error_last)*CCD_PID_KD;
	
	return pid_out;
}


//直接控制pwm   Directly control pwm
void motion_car_control(int16_t V_x, int16_t V_y, int16_t V_z)
{	
	float robot_APB = Motion_Get_APB();
	speed_lr = 0;
    speed_fb = V_x;
    speed_spin = (V_z / 1000.0f) * robot_APB;
    if (V_x == 0 && V_y == 0 && V_z == 0)
    {
        Motion_Set_Pwm(0,0,0,0);
        return;
    }

		
	speed_L1_setup = speed_fb + speed_spin;
    speed_R1_setup = speed_fb + speed_spin;
    speed_L2_setup = speed_fb  - speed_spin;
    speed_R2_setup = speed_fb  - speed_spin;
		
	if (speed_L1_setup > 1000) speed_L1_setup = 1000;
	if (speed_L1_setup < -1000) speed_L1_setup = -1000;
	if (speed_L2_setup > 1000) speed_L2_setup = 1000;
	if (speed_L2_setup < -1000) speed_L2_setup = -1000;
	if (speed_R1_setup > 1000) speed_R1_setup = 1000;
	if (speed_R1_setup < -1000) speed_R1_setup = -1000;
	if (speed_R2_setup > 1000) speed_R2_setup = 1000;
	if (speed_R2_setup < -1000) speed_R2_setup = -1000;
	
	Motion_Set_Pwm(speed_L1_setup, speed_L2_setup, speed_R1_setup, speed_R2_setup);
		
}


// 控制小车运动，Motor_X=[-1000, 1000]，超过范围则无效。
//Control the movement of the car, Motor_ X=[-1000, 1000], if it exceeds the range, it is invalid.
void Motion_Set_Pwm(int16_t Motor_1, int16_t Motor_2, int16_t Motor_3, int16_t Motor_4)
{
    if (Motor_1 >= -MOTOR_MAX_PULSE && Motor_1 <= MOTOR_MAX_PULSE)
    {
        Motor_Set_Pwm(MOTOR_ID_M1, Motor_1);
    }
    if (Motor_2 >= -MOTOR_MAX_PULSE && Motor_2 <= MOTOR_MAX_PULSE)
    {
        Motor_Set_Pwm(MOTOR_ID_M2, Motor_2);
    }
    if (Motor_3 >= -MOTOR_MAX_PULSE && Motor_3 <= MOTOR_MAX_PULSE)
    {
        Motor_Set_Pwm(MOTOR_ID_M3, Motor_3);
    }
    if (Motor_4 >= -MOTOR_MAX_PULSE && Motor_4 <= MOTOR_MAX_PULSE)
    {
        Motor_Set_Pwm(MOTOR_ID_M4, Motor_4);
    }
}


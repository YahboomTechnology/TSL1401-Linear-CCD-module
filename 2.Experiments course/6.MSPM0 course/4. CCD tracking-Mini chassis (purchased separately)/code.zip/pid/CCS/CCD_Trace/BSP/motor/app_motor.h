#ifndef __APP_MOTOR_H
#define __APP_MOTOR_H

#include "ALLHeader.h"

//С�����̵�����֮�͵�һ��
//Half of the sum of the distances between the chassis and motors of the trolley
#define STM32Car_APB          				(150.0f)//195 105


void Motion_Set_Pwm(int16_t Motor_1, int16_t Motor_2, int16_t Motor_3, int16_t Motor_4);
float APP_ELE_PID_Calc(int8_t actual_value);
void motion_car_control(int16_t V_x, int16_t V_y, int16_t V_z);

#endif

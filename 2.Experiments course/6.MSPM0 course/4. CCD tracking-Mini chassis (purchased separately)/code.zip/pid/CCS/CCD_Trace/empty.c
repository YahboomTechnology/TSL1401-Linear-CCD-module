#include "ALLHeader.h"


int main(void)
{	
    USART_Init();//Initialization function     ��ʼ������	
		
	NVIC_EnableIRQ(AO_INST_INT_IRQN);//ʹ��ADC�ж�  Enable ADC interrupt
	
	
    while(1)
    {
		deal_data_ccd();
		use_ccd_line_motion_PID();
		delay_ms(6);
    }
}

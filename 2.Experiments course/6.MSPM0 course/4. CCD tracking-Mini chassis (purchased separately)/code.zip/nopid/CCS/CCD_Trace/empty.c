#include "ALLHeader.h"

uint8_t p_img_last[128]={'\0'};


void LCD_Show_CCD_Image(uint8_t* p_img)
{
	for (int i = 0; i < 128; i++)
    {
			LCD_DrawPoint(i, p_img_last[i], BLACK);
		}
	
	
	for (int i = 15; i < 128; i++)
    {
        if (p_img[i] < 64)
        {
          LCD_DrawPoint(i, p_img[i], WHITE);
					p_img_last[i] = p_img[i];
        }
    }
	
}

int main(void)
{	
    USART_Init();//Initialization function     ��ʼ������	
		
	NVIC_EnableIRQ(AO_INST_INT_IRQN);//ʹ��ADC�ж�  Enable ADC interrupt
	
	LCD_Init();//LCD��ʼ��  LCD Initialization
	LCD_Fill(0,0,LCD_W,LCD_H,BLACK); //���� Clear screen

    while(1)
    {
		deal_data_ccd();
		LCD_Show_CCD_Image(CCD_Get_ADC_128X64());
		use_ccd_line_motion();
    }
}

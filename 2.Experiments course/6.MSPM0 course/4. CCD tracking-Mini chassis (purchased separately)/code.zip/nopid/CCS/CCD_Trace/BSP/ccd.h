#ifndef __CCD_H
#define __CCD_H	

#include "ALLHeader.h"


#define TSL_SI(state) ((state) ? DL_GPIO_setPins(CCD_PORT, CCD_SI_PIN) : DL_GPIO_clearPins(CCD_PORT, CCD_SI_PIN))   //SI  
#define TSL_CLK(state) ((state) ? DL_GPIO_setPins(CCD_PORT, CCD_CLK_PIN) : DL_GPIO_clearPins(CCD_PORT, CCD_CLK_PIN))  //CLK


extern volatile uint16_t ADC_VALUE[20];
unsigned int adc_getValue(void);
void RD_TSL(void); 
void CCD(void);
void ccd_Init(void);
char binToHex_high(uint8_t num);
char binToHex_low(uint8_t num);
void slove_data(void);
void sendToPc(void);
void deal_data_ccd(void);
void use_ccd_line_motion(void);
void  Find_CCD_Zhongzhi(void);

uint8_t* CCD_Get_ADC_128X64(void);

#endif 



#ifndef __LCD_INIT_H
#define __LCD_INIT_H

#include "ALLHeader.h"

#define USE_HORIZONTAL 2  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����
                          //Set the screen to horizontal or vertical. 0 or 1 for vertical screen, 2 or 3 for horizontal screen.


#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 80
#define LCD_H 160

#else
#define LCD_W 160
#define LCD_H 80
#endif



//-----------------LCD�˿ڶ���----------------//
//-----------------LCD port definition---------------- //
#define LCD_SCLK_Clr() DL_GPIO_clearPins(LCD_SCLK_PORT,LCD_SCLK_PIN)//SCL=SCLK
#define LCD_SCLK_Set() DL_GPIO_setPins(LCD_SCLK_PORT,LCD_SCLK_PIN)

#define LCD_MOSI_Clr() DL_GPIO_clearPins(LCD_MOSI_PORT,LCD_MOSI_PIN)//SDA=MOSI
#define LCD_MOSI_Set() DL_GPIO_setPins(LCD_MOSI_PORT,LCD_MOSI_PIN)

#define LCD_RES_Clr()  DL_GPIO_clearPins(LCD_RES_PORT,LCD_RES_PIN)//RES
#define LCD_RES_Set()  DL_GPIO_setPins(LCD_RES_PORT,LCD_RES_PIN)

#define LCD_DC_Clr()   DL_GPIO_clearPins(LCD_DC_PORT,LCD_DC_PIN)//DC
#define LCD_DC_Set()   DL_GPIO_setPins(LCD_DC_PORT,LCD_DC_PIN)
 		     
#define LCD_CS_Clr()   DL_GPIO_clearPins(LCD_CS_PORT,LCD_CS_PIN)//CS
#define LCD_CS_Set()   DL_GPIO_clearPins(LCD_CS_PORT,LCD_CS_PIN) //DL_GPIO_setPins(CS_PORT,CS_PIN_23_PIN)

#define LCD_BLK_Clr()  DL_GPIO_clearPins(LCD_BLK_PORT,LCD_BLK_PIN)//BLK
#define LCD_BLK_Set()  DL_GPIO_setPins(LCD_BLK_PORT,LCD_BLK_PIN)

void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ�� Simulate SPI timing
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�    Write a byte
void LCD_WR_DATA(u16 dat);//д�������ֽ�    Write two bytes
void LCD_WR_REG(u8 dat);//д��һ��ָ��  Write a command
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��    Set coordinate function
void LCD_Init(void);//LCD��ʼ�� LCD Initialization

#endif





#ifndef __ALLHEADER_H
#define __ALLHEADER_H


#include <stdio.h>
#include "stdint.h"
#include <string.h>
#include "ti_msp_dl_config.h"

typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;

#include "delay.h"
#include "lcd_init.h"
#include "lcd.h"
#include "usart.h"	 
#include "ccd.h"
#include "app_motor.h"
#include "bsp_motor.h"





#endif


